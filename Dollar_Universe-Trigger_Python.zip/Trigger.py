#!/usr/bin/python
import triggerlib,argparse,sys

# Parsing Arguments
parser = argparse.ArgumentParser(prog='tool', formatter_class=lambda prog: argparse.HelpFormatter(prog,max_help_position=100))
parser.add_argument('-host','-s',required=True, metavar='<hostname>', type=str, nargs=1, help='MANDATORY - UVMS HOSTNAME')
parser.add_argument('-port','-o',required=True, metavar='<port number>', type=str, nargs=1, help='MANDATORY - UVMS Port')
parser.add_argument('-login','-l',required=True, metavar='<uvms login>', type=str, nargs=1, help='MANDATORY - UVMS Login')
parser.add_argument('-pwd','-p',required=True, metavar='<uvms pwd>', type=str, nargs=1, help='MANDATORY - UVMS Password')
parser.add_argument('-evttypename','-e',required=True, metavar='<trigger type name>', type=str, nargs=1, help='MANDATORY - Trigger Type Name') 
args = parser.parse_args()

## Retrieving Arguments ##

HOSTNAME=args.host[0]
PORT=args.port[0]
UVMS_LOGIN=args.login[0]
UVMS_PWD=args.pwd[0]
DU_EVENT_TYPE_NAME=args.evttypename[0]

#HOSTNAME = 'bsalinux06'
#PORT = '6000'
#UVMS_LOGIN = 'admin'
#UVMS_PWD = 'universe'
#DU_EVENT_TYPE_NAME = 'MYTEST'

#Authenticating
AUTH_TOKEN = triggerlib.GetAuthToken(HOSTNAME,PORT,UVMS_LOGIN,UVMS_PWD)

print 'Authentication OK, Token is: ' + AUTH_TOKEN

#Triggering
RESPONSE = triggerlib.StartTrigger(HOSTNAME,PORT,AUTH_TOKEN,DU_EVENT_TYPE_NAME)

# Reading and Processing the Response
Status = RESPONSE['status']
Data = RESPONSE['data']
LaunchNumber = Data[0]['launch_number']
TriggerName = Data[0]['trigger']
print 'Status is: [' + Status + '] For Trigger: [' + TriggerName + ']'
print 'Launch Number is: ' + LaunchNumber

# Deleting the Auth Token generated
triggerlib.DeleteToken(HOSTNAME,PORT,AUTH_TOKEN)
print 'Authentication Token Deleted'
sys.exit(0)