#!/usr/bin/python
##################################################
##
##    Python Library for ORSYP Trigger API
##
##################################################
import urllib
import urllib2
import json
import sys

def GetAuthToken(hostname,port,login,password):
	URL_ROOT = 'http://'+hostname+':'+port
	AUTH_TOKEN=''
	# Building and Submitting the URL for Authentication Request
	GET_URL= URL_ROOT+'/access?user='+login+'&pwd='+password
	response = json.load(urllib2.urlopen(GET_URL))
	# Getting and Processing the JSON response (the Auth token)
	AUTH_TOKEN = response['data'][0]['token']
	return AUTH_TOKEN

def StartTrigger(hostname, port, token, eventtypename):
	URL_ROOT = 'http://'+hostname+':'+port
	POST_URL = URL_ROOT+'/event'

	values = {'type' : eventtypename}
	headers = {'Authorization' : token}
	data = urllib.urlencode(values)
	req = urllib2.Request(POST_URL,data,headers)
	response = json.load(urllib2.urlopen(req))
	Status = response['status']
	return response

def DeleteToken(hostname, port, token):
	URL_ROOT = 'http://'+hostname+':'+port
	DELETE_URL=URL_ROOT + '/access?token='+ token	
	request = urllib2.Request(DELETE_URL)
	request.get_method = lambda: 'DELETE'
	urllib2.urlopen(request)